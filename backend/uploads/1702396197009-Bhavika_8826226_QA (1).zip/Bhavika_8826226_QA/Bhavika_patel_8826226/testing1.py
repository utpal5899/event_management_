# import time
import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.implicitly_wait(5)
driver.get('https://ca.puma.com/ca/en')
driver.find_element(By.ID, 'search-button-nav').click()

print("Search button")
time.sleep(100)